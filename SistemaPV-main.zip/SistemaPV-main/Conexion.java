package conexion;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

/**
 *
 * @author angela
 */
public class Conexion {
    Connection cn;
    
//conexion local
    public Connection conectar(){
    try{
    Class.forName("com.mysql.jdbc.Driver");
    cn = DriverManager.getConnection("jdbc:mysql://localhost/bd_sistemas_ventas","root","leo2409");  
    System.out.println("Conectado");
    }catch (ClassNotFoundException | SQLException e){
    System.out.println("Error de conexión"+e);
    }
    return cn;
    } 
}


